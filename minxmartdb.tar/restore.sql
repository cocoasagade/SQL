--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6
-- Dumped by pg_dump version 15.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE minxmartdb;
--
-- Name: minxmartdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE minxmartdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United Kingdom.1252';


ALTER DATABASE minxmartdb OWNER TO postgres;

\connect minxmartdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer,
    customer_name character varying
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location (
    store_id integer,
    city_name character varying,
    county character varying,
    state_code character varying,
    state character varying,
    type character varying
);


ALTER TABLE public.location OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id integer,
    product_name character varying
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.region (
    state_code character varying,
    state character varying,
    region character varying
);


ALTER TABLE public.region OWNER TO postgres;

--
-- Name: sales_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_order (
    order_number character varying,
    sales_channel character varying,
    order_date date,
    ship_date date,
    delivery_date date,
    salesteam_id integer,
    customer_id integer,
    store_id integer,
    product_id integer,
    order_quantity integer,
    discount_applied numeric,
    unit_price numeric,
    unit_cost numeric
);


ALTER TABLE public.sales_order OWNER TO postgres;

--
-- Name: sales_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_team (
    salesteam_id integer,
    name character varying,
    region character varying
);


ALTER TABLE public.sales_team OWNER TO postgres;

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, customer_name) FROM stdin;
\.
COPY public.customer (customer_id, customer_name) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location (store_id, city_name, county, state_code, state, type) FROM stdin;
\.
COPY public.location (store_id, city_name, county, state_code, state, type) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (product_id, product_name) FROM stdin;
\.
COPY public.product (product_id, product_name) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.region (state_code, state, region) FROM stdin;
\.
COPY public.region (state_code, state, region) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: sales_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_order (order_number, sales_channel, order_date, ship_date, delivery_date, salesteam_id, customer_id, store_id, product_id, order_quantity, discount_applied, unit_price, unit_cost) FROM stdin;
\.
COPY public.sales_order (order_number, sales_channel, order_date, ship_date, delivery_date, salesteam_id, customer_id, store_id, product_id, order_quantity, discount_applied, unit_price, unit_cost) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: sales_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_team (salesteam_id, name, region) FROM stdin;
\.
COPY public.sales_team (salesteam_id, name, region) FROM '$$PATH$$/3338.dat';

--
-- PostgreSQL database dump complete
--

